import os
from flask import Flask, request, jsonify, render_template
import pdfplumber
import docx

app = Flask(__name__)

# Ensure the uploads directory exists to prevent FileNotFoundError
UPLOAD_FOLDER = "uploads"
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# Expanded IT Job Roles Catalog
job_roles = {
    "cloud_engineer": ["python", "aws", "cloud", "linux", "sql", "terraform", "docker", "kubernetes", "devops", "azure"],
    "java_developer": ["java", "spring", "hibernate", "sql", "oop", "maven", "microservices", "rest api", "git", "junit"],
    "data_scientist": ["python", "machine learning", "statistics", "sql", "pandas", "numpy", "scikit-learn", "deep learning", "r", "tableau"],
    "frontend_developer": ["html", "css", "javascript", "react", "vue", "angular", "typescript", "tailwind", "sass", "git"],
    "backend_developer": ["python", "node.js", "express", "django", "postgresql", "mongodb", "restful api", "redis", "docker", "graphql"],
    "devops_engineer": ["linux", "bash", "docker", "kubernetes", "jenkins", "ci/cd", "ansible", "terraform", "aws", "prometheus"],
    "cybersecurity_analyst": ["wireshark", "linux", "siem", "firewall", "network security", "pentesting", "metasploit", "cryptography", "owasp", "incident response"],
    "qa_automation_engineer": ["selenium", "cucumber", "testng", "java", "python", "playwright", "automation", "api testing", "jira", "postman"]
}

def extract_text(file_path):
    text = ""
    if file_path.endswith(".pdf"):
        with pdfplumber.open(file_path) as pdf:
            for page in pdf.pages:
                text += page.extract_text() or ""
    elif file_path.endswith(".docx"):
        doc = docx.Document(file_path)
        for para in doc.paragraphs:
            text += para.text + " "
    return text.lower()

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/upload", methods=["POST"])
def upload():
    # Defensive check: ensure the file exists in the request
    if "resume" not in request.files or request.files["resume"].filename == '':
        return jsonify({"error": "No resume file uploaded"}), 400
        
    file = request.files["resume"]
    role = request.form.get("role", "")
    
    file_path = os.path.join(UPLOAD_FOLDER, file.filename)
    file.save(file_path)

    resume_text = extract_text(file_path)
    required_skills = job_roles.get(role, [])
    
    # Keyword extraction math
    matched = [skill for skill in required_skills if skill in resume_text]
    percentage = (len(matched) / len(required_skills)) * 100 if required_skills else 0
    status = "Eligible" if percentage >= 50 else "Not Eligible"

    return jsonify({
        "role": role, 
        "skills_found": matched, 
        "percentage": percentage, 
        "status": status
    })

if __name__ == "__main__":
    app.run(debug=True)