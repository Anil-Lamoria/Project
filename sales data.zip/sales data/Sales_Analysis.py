import pandas as pd

df = pd.read_csv("sales data.csv")
print(df)

# duplicate remove
df = df.drop_duplicates()
print(df)

# fix date column
df['Order_Date'] = pd.to_datetime(df['Order_Date'], errors='coerce')

df = df.dropna(subset=['Order_Date'])
print(df)

# create column
df['Profit'] = df['Sales']-df['Cost']
df['Year'] = df['Order_Date'].dt.year
df['Month'] = df['Order_Date'].dt.month
print(df)

df.to_csv('sales_cleaned.csv', index = False)